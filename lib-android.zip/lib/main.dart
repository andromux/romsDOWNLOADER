import 'dart:async';
import 'dart:io';
import 'dart:isolate';
import 'dart:ui';
import 'package:dio/dio.dart';
import 'package:external_path/external_path.dart';
import 'package:file_picker/file_picker.dart'; // NUEVO: File Picker
import 'package:flutter/material.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

// ============================================================================
// 1. CONFIGURACIÓN E INICIALIZACIÓN
// ============================================================================

const String kApiBaseUrl = "https://api.crocdb.net";
const double kBorderRadius = 24.0;

@pragma('vm:entry-point')
void downloadCallback(String id, int status, int progress) {
  final SendPort? send = IsolateNameServer.lookupPortByName('downloader_send_port');
  send?.send([id, status, progress]);
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  if (Platform.isAndroid || Platform.isIOS) {
    await FlutterDownloader.initialize(debug: true, ignoreSsl: true);
  }

  runApp(const ProviderScope(child: CrocDbApp()));
}

class AppColors {
  static const Color darkBg = Color(0xFF0A0A0F);
  static const Color darkSurface = Color(0xFF161622);
  static const Color neonCyan = Color(0xFF00FFFF);
  static const Color neonMagenta = Color(0xFFFF00FF);
  static const Color neonPurple = Color(0xFFBC13FE);
  static const Color lightBg = Color(0xFFF5F5FA);
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color lightAccent = Color(0xFF6366F1);
}

// ============================================================================
// 2. MODELOS DE DATOS
// ============================================================================

class ConsolePlatform {
  final String id;
  final String name;
  final String brand;
  ConsolePlatform({required this.id, required this.name, required this.brand});
}

class Rom {
  final String title;
  final String platform;
  final List<String> regions;
  final String romId;
  final String slug;
  final String? coverUrl; 
  final List<DownloadLink> links;

  Rom({
    required this.title, required this.platform, required this.regions,
    required this.romId, required this.slug, this.coverUrl, required this.links,
  });

  factory Rom.fromJson(Map<String, dynamic> json) {
    return Rom(
      title: json['title'] ?? 'Unknown Title',
      platform: json['platform'] ?? 'unknown',
      regions: (json['regions'] as List?)?.map((e) => e.toString()).toList() ?? [],
      romId: json['rom_id']?.toString() ?? '',
      slug: json['slug'] ?? '',
      links: (json['links'] as List?)?.map((e) => DownloadLink.fromJson(e)).toList() ?? [],
    );
  }
}

class DownloadLink {
  final String name;
  final String format;
  final String sizeStr;
  final String url;
  final String host;

  DownloadLink({required this.name, required this.format, required this.sizeStr, required this.url, required this.host});

  factory DownloadLink.fromJson(Map<String, dynamic> json) {
    return DownloadLink(
      name: json['name'] ?? 'file',
      format: json['format'] ?? '',
      sizeStr: json['size_str'] ?? '',
      url: json['url'] ?? '',
      host: json['host'] ?? '',
    );
  }
}

class DownloadTaskModel {
  final String id;
  final String fileName;
  final double progress;
  final bool isDownloading;
  final bool isCompleted;
  final bool isError;
  final String statusMessage;
  final String? finalPath; // Ruta final donde quedó el archivo

  DownloadTaskModel({
    required this.id, required this.fileName, this.progress = 0.0,
    this.isDownloading = false, this.isCompleted = false, this.isError = false,
    this.statusMessage = 'Pendiente', this.finalPath,
  });

  DownloadTaskModel copyWith({
    double? progress, bool? isDownloading, bool? isCompleted, bool? isError,
    String? statusMessage, String? finalPath,
  }) {
    return DownloadTaskModel(
      id: id, fileName: fileName,
      progress: progress ?? this.progress,
      isDownloading: isDownloading ?? this.isDownloading,
      isCompleted: isCompleted ?? this.isCompleted,
      isError: isError ?? this.isError,
      statusMessage: statusMessage ?? this.statusMessage,
      finalPath: finalPath ?? this.finalPath,
    );
  }
}

// ============================================================================
// 3. REPOSITORIOS
// ============================================================================

class ApiService {
  final Dio _dio = Dio(BaseOptions(baseUrl: kApiBaseUrl));

  Future<List<Rom>> searchRoms({required String query, List<String>? platforms}) async {
    try {
      final payload = {
        "search_key": query, "max_results": 50, "page": 1,
        if (platforms != null && platforms.isNotEmpty) "platforms": platforms,
      };
      final response = await _dio.post('/search', data: payload);
      if (response.data != null && response.data['data'] != null) {
        return (response.data['data']['results'] as List).map((e) => Rom.fromJson(e)).toList();
      }
      return [];
    } catch (e) { return []; }
  }

  List<ConsolePlatform> getInitialConsoles() {
    return [
      ConsolePlatform(id: 'n64', name: 'Nintendo 64', brand: 'Nintendo'),
      ConsolePlatform(id: 'nes', name: 'NES', brand: 'Nintendo'),
      ConsolePlatform(id: 'snes', name: 'Super Nintendo', brand: 'Nintendo'),
      ConsolePlatform(id: 'gba', name: 'Game Boy Advance', brand: 'Nintendo'),
      ConsolePlatform(id: 'ps1', name: 'PlayStation', brand: 'Sony'),
      ConsolePlatform(id: 'genesis', name: 'Sega Genesis', brand: 'Sega'),
      ConsolePlatform(id: 'dreamcast', name: 'Dreamcast', brand: 'Sega'),
      ConsolePlatform(id: 'nds', name: 'Nintendo DS', brand: 'Nintendo'),
      ConsolePlatform(id: 'psp', name: 'PSP', brand: 'Sony'),
    ];
  }
}

// ============================================================================
// 4. GESTIÓN DE ESTADO (RIVERPOD)
// ============================================================================

final themeProvider = StateProvider<ThemeMode>((ref) => ThemeMode.dark);
final apiServiceProvider = Provider((ref) => ApiService());
final navIndexProvider = StateProvider<int>((ref) => 0);

// Search
class SearchState {
  final bool isLoading;
  final List<Rom> results;
  final String activePlatformFilter; 
  SearchState({this.isLoading = false, this.results = const [], this.activePlatformFilter = ''});
  SearchState copyWith({bool? isLoading, List<Rom>? results, String? activePlatformFilter}) {
    return SearchState(
      isLoading: isLoading ?? this.isLoading,
      results: results ?? this.results,
      activePlatformFilter: activePlatformFilter ?? this.activePlatformFilter,
    );
  }
}

class SearchNotifier extends StateNotifier<SearchState> {
  final ApiService _api;
  SearchNotifier(this._api) : super(SearchState());

  Future<void> search(String query) async {
    if (query.isEmpty && state.activePlatformFilter.isEmpty) return;
    state = state.copyWith(isLoading: true);
    try {
      List<String>? platforms;
      if (state.activePlatformFilter.isNotEmpty) platforms = [state.activePlatformFilter];
      final results = await _api.searchRoms(query: query.isEmpty ? "mario" : query, platforms: platforms);
      state = state.copyWith(isLoading: false, results: results);
    } catch (e) { state = state.copyWith(isLoading: false); }
  }

  void setPlatformFilter(String platformId) => state = state.copyWith(activePlatformFilter: platformId, results: []); 
  void clearFilter() => state = state.copyWith(activePlatformFilter: '', results: []);
}

final searchProvider = StateNotifierProvider<SearchNotifier, SearchState>((ref) => SearchNotifier(ref.read(apiServiceProvider)));

// DOWNLOAD NOTIFIER (Lógica de Descarga y Movimiento)
class DownloadNotifier extends StateNotifier<List<DownloadTaskModel>> {
  final Dio _dio = Dio();
  DownloadNotifier() : super([]);

  void updateFromBackground(String id, int status, int progress) {
    final taskStatus = DownloadTaskStatus.fromInt(status);
    
    // Si se completó en Android, iniciamos el movimiento a la carpeta pública
    if (taskStatus == DownloadTaskStatus.complete) {
      _finalizeAndroidDownload(id);
    }

    state = [
      for (final t in state)
        if (t.id == id)
          t.copyWith(
            progress: progress / 100.0,
            isDownloading: taskStatus == DownloadTaskStatus.running || taskStatus == DownloadTaskStatus.enqueued,
            isCompleted: taskStatus == DownloadTaskStatus.complete,
            isError: taskStatus == DownloadTaskStatus.failed,
            statusMessage: _getStatusMessage(taskStatus, progress),
          )
        else t
    ];
  }

  // Se llama al terminar la descarga en Android para mover el archivo
  Future<void> _finalizeAndroidDownload(String taskId) async {
    final taskIndex = state.indexWhere((t) => t.id == taskId);
    if (taskIndex == -1) return;
    final task = state[taskIndex];

    try {
      // 1. Ruta de origen (Privada)
      final appDir = await getApplicationSupportDirectory();
      final sourceFile = File('${appDir.path}/${task.fileName}');

      if (!await sourceFile.exists()) {
        print("Error: Archivo original no encontrado en ${sourceFile.path}");
        return;
      }

      // 2. Ruta de destino (Pública - Documents)
      final documentsPath = await ExternalPath.getExternalStoragePublicDirectory(ExternalPath.DIRECTORY_DOCUMENTS);
      final targetDir = Directory('$documentsPath/RomsDownloader'); // Carpeta propia para orden
      if (!await targetDir.exists()) {
        await targetDir.create(recursive: true);
      }

      final targetFile = File('${targetDir.path}/${task.fileName}');

      // 3. Copiar
      await sourceFile.copy(targetFile.path);
      
      // 4. Eliminar original para ahorrar espacio (opcional)
      await sourceFile.delete();

      // 5. Actualizar estado con la ruta final real
      state = [
        for (final t in state)
          if (t.id == taskId)
            t.copyWith(
              statusMessage: 'Guardado en Documents/RomsDownloader',
              finalPath: targetFile.path
            )
          else t
      ];

    } catch (e) {
      print("Error moviendo archivo: $e");
      state = [
        for (final t in state)
          if (t.id == taskId)
            t.copyWith(statusMessage: 'Error moviendo a Docs. Usa "Exportar".')
          else t
      ];
    }
  }

  String _getStatusMessage(DownloadTaskStatus status, int progress) {
    if (status == DownloadTaskStatus.enqueued) return "En cola...";
    if (status == DownloadTaskStatus.running) return "Descargando $progress%";
    if (status == DownloadTaskStatus.complete) return "Procesando..."; // Cambiado para indicar el movimiento
    if (status == DownloadTaskStatus.failed) return "Falló";
    return "Pendiente";
  }

  Future<void> startDownload(DownloadLink link) async {
    if (Platform.isAndroid) {
      // 1. Permisos (Manage External Storage para Android 11+)
      if (await Permission.manageExternalStorage.request().isDenied) {
         // Fallback para Android 10 o inferior
         await Permission.storage.request();
      }

      // 2. Descargar a carpeta PRIVADA primero (Truco clave)
      // Flutter Downloader falla a veces escribiendo directo en Documents.
      // Escribimos en la carpeta de la app, y luego lo movemos con código Dart.
      final appDir = await getApplicationSupportDirectory();
      final fileName = link.name.isNotEmpty ? link.name : 'download_${DateTime.now().millisecondsSinceEpoch}.zip';

      final taskId = await FlutterDownloader.enqueue(
        url: link.url,
        savedDir: appDir.path, // Guardar en privado primero
        fileName: fileName,
        showNotification: true,
        openFileFromNotification: false, // Falso porque lo moveremos
        saveInPublicStorage: false,
      );

      if (taskId != null) {
        final task = DownloadTaskModel(
          id: taskId,
          fileName: fileName,
          isDownloading: true,
          statusMessage: 'Iniciando...',
        );
        state = [...state, task];
      }
      return;
    }

    // Lógica Desktop (Sin cambios)
    // ... (Mismo código de antes para Linux/Windows con Dio)
  }

  // NUEVA FUNCIÓN: Exportar manualmente usando File Picker
  Future<void> exportFile(DownloadTaskModel task) async {
    if (task.finalPath == null) return;
    
    try {
      // Abrir diálogo para seleccionar carpeta
      String? selectedDirectory = await FilePicker.platform.getDirectoryPath(
        dialogTitle: "Selecciona dónde guardar ${task.fileName}"
      );

      if (selectedDirectory != null) {
        final sourceFile = File(task.finalPath!);
        final newPath = '$selectedDirectory/${task.fileName}';
        await sourceFile.copy(newPath);
        
        state = [
          for (final t in state)
            if (t.id == task.id) t.copyWith(statusMessage: 'Exportado exitosamente!') else t
        ];
      }
    } catch (e) {
      state = [
        for (final t in state)
          if (t.id == task.id) t.copyWith(statusMessage: 'Error al exportar') else t
      ];
    }
  }
}

final downloadsProvider = StateNotifierProvider<DownloadNotifier, List<DownloadTaskModel>>((ref) => DownloadNotifier());
final activeDownloadsCountProvider = Provider<int>((ref) => ref.watch(downloadsProvider).where((t) => t.isDownloading).length);

// ============================================================================
// 5. WIDGETS DE UI & LISTENER
// ============================================================================

class DownloadPortListener extends ConsumerStatefulWidget {
  final Widget child;
  const DownloadPortListener({super.key, required this.child});
  @override
  ConsumerState<DownloadPortListener> createState() => _DownloadPortListenerState();
}

class _DownloadPortListenerState extends ConsumerState<DownloadPortListener> {
  final ReceivePort _port = ReceivePort();

  @override
  void initState() {
    super.initState();
    if (Platform.isAndroid || Platform.isIOS) {
      IsolateNameServer.registerPortWithName(_port.sendPort, 'downloader_send_port');
      _port.listen((dynamic data) {
        String id = data[0];
        int status = data[1];
        int progress = data[2];
        ref.read(downloadsProvider.notifier).updateFromBackground(id, status, progress);
      });
      FlutterDownloader.registerCallback(downloadCallback);
    }
  }

  @override
  void dispose() {
    if (Platform.isAndroid || Platform.isIOS) IsolateNameServer.removePortNameMapping('downloader_send_port');
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.child;
}

// ... (Widgets estéticos RetroBackground, GridPainter, GlassCard se mantienen igual)
// He omitido repetirlos para ahorrar espacio, pero asegúrate de incluirlos o copiarlos del código anterior.
// Incluyo aquí solo las pantallas modificadas.

// ============================================================================
// 6. PANTALLAS MODIFICADAS (SHEET DE DESCARGAS)
// ============================================================================

class DownloadsSheet extends ConsumerWidget {
  const DownloadsSheet({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final downloads = ref.watch(downloadsProvider);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      decoration: BoxDecoration(
        color: isDark ? AppColors.darkSurface : Colors.white,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
      ),
      padding: const EdgeInsets.all(20),
      height: MediaQuery.of(context).size.height * 0.6,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("GESTOR DE DESCARGAS", style: GoogleFonts.orbitron(fontSize: 18, fontWeight: FontWeight.bold)),
              IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(context))
            ],
          ),
          const Divider(),
          Expanded(
            child: downloads.isEmpty
                ? Center(child: Text("No hay descargas activas", style: TextStyle(color: Colors.grey)))
                : ListView.builder(
                    itemCount: downloads.length,
                    itemBuilder: (context, index) {
                      final task = downloads[index];
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: isDark ? Colors.black26 : Colors.grey.shade100,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.grey.withOpacity(0.2)),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(child: Text(task.fileName, maxLines: 1, overflow: TextOverflow.ellipsis)),
                                  if (task.isCompleted)
                                    // Botón EXPORTAR (File Picker)
                                    IconButton(
                                      icon: const Icon(Icons.save_as, color: Colors.blue),
                                      tooltip: "Exportar a otra carpeta",
                                      onPressed: () {
                                        ref.read(downloadsProvider.notifier).exportFile(task);
                                      },
                                    )
                                  else if (task.isError)
                                    const Icon(Icons.error, color: Colors.red, size: 20),
                                ],
                              ),
                              const SizedBox(height: 8),
                              LinearProgressIndicator(
                                value: task.progress,
                                backgroundColor: Colors.grey.withOpacity(0.2),
                                color: task.isError ? Colors.red : (task.isCompleted ? Colors.green : AppColors.neonCyan),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                task.statusMessage,
                                style: const TextStyle(fontSize: 10, color: Colors.grey),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

// ... (El resto de la UI: Console3DCard, MainLayoutScreen, etc., se mantiene igual que en la versión anterior)
// Copia las clases de UI (RetroBackground, GridPainter, GlassCard, MainLayoutScreen, etc) del código previo si no las tienes.
// Solo asegúrate de que el `main` llame a `CrocDbApp` envuelta en `DownloadPortListener`.

// REINCORPORO LA UI NECESARIA PARA QUE COMPILE DE UNA VEZ:

class RetroBackground extends StatelessWidget {
  final Widget child;
  const RetroBackground({super.key, required this.child});
  @override
  Widget build(BuildContext context) {
    return Container(color: Theme.of(context).scaffoldBackgroundColor, child: child); 
    // (Simplificado para brevedad, puedes usar el completo con grid y blur)
  }
}

class GlassCard extends StatelessWidget {
  final Widget child;
  final VoidCallback? onTap;
  final double opacity;
  const GlassCard({super.key, required this.child, this.onTap, this.opacity = 0.05});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Theme.of(context).brightness == Brightness.dark ? Colors.white.withOpacity(opacity) : Colors.black.withOpacity(opacity),
          borderRadius: BorderRadius.circular(24),
        ),
        child: child,
      ),
    );
  }
}

class Console3DCard extends StatelessWidget {
  final ConsolePlatform console;
  final VoidCallback onTap;
  const Console3DCard({super.key, required this.console, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [Colors.blue.shade900, Colors.purple.shade900]),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Center(child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(FontAwesomeIcons.gamepad, color: Colors.white, size: 40),
            SizedBox(height: 10),
            Text(console.name, style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
          ],
        )),
      ),
    );
  }
}

class GlobalDownloadButton extends ConsumerWidget {
  const GlobalDownloadButton({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final activeCount = ref.watch(activeDownloadsCountProvider);
    return FloatingActionButton(
      onPressed: () => showModalBottomSheet(context: context, builder: (ctx) => const DownloadsSheet()),
      child: Badge(
        isLabelVisible: activeCount > 0,
        label: Text(activeCount.toString()),
        child: const Icon(Icons.download),
      ),
    );
  }
}

class CrocDbApp extends ConsumerWidget {
  const CrocDbApp({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return MaterialApp(
      title: 'CrocDB',
      themeMode: ref.watch(themeProvider),
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
      home: const DownloadPortListener(child: MainLayoutScreen()),
    );
  }
}

class MainLayoutScreen extends ConsumerWidget {
  const MainLayoutScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final idx = ref.watch(navIndexProvider);
    return Scaffold(
      body: idx == 0 ? const HomeConsolesTab() : const SearchRomTab(),
      bottomNavigationBar: NavigationBar(
        selectedIndex: idx,
        onDestinationSelected: (i) => ref.read(navIndexProvider.notifier).state = i,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.gamepad), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.search), label: 'Search'),
        ],
      ),
      floatingActionButton: const GlobalDownloadButton(),
    );
  }
}

class HomeConsolesTab extends ConsumerWidget {
  const HomeConsolesTab({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final consoles = ref.read(apiServiceProvider).getInitialConsoles();
    return GridView.builder(
      padding: const EdgeInsets.all(20),
      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 200, mainAxisSpacing: 10, crossAxisSpacing: 10),
      itemCount: consoles.length,
      itemBuilder: (ctx, i) => Console3DCard(console: consoles[i], onTap: () {
        ref.read(searchProvider.notifier).setPlatformFilter(consoles[i].id);
        ref.read(navIndexProvider.notifier).state = 1;
      }),
    );
  }
}

class SearchRomTab extends ConsumerWidget {
  const SearchRomTab({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(searchProvider);
    return Column(children: [
      Padding(padding: EdgeInsets.all(20), child: TextField(
        onSubmitted: (val) => ref.read(searchProvider.notifier).search(val),
        decoration: InputDecoration(hintText: "Search...", prefixIcon: Icon(Icons.search), border: OutlineInputBorder(borderRadius: BorderRadius.circular(30))),
      )),
      if (state.isLoading) const CircularProgressIndicator(),
      Expanded(child: ListView.builder(
        itemCount: state.results.length,
        itemBuilder: (ctx, i) => ListTile(
          title: Text(state.results[i].title),
          trailing: IconButton(
            icon: Icon(Icons.download),
            onPressed: () {
              if (state.results[i].links.isNotEmpty) {
                ref.read(downloadsProvider.notifier).startDownload(state.results[i].links.first);
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Descarga iniciada")));
              }
            },
          ),
        ),
      ))
    ]);
  }
}